// toc.js — Mục lục chương của truyện Inkitt
// Contract: execute(url) → [{name*, url*, host?}]
// TOC is on the detail page: chapters are listed as a[href*="/chapters/"]
// URL pattern: https://www.inkitt.com/stories/1698711
load('config.js');
function execute(url) {
    // Normalize URL — strip trailing slash, strip chapter path if appended
    url = url.replace(/^https?:\/\/(www\.)?inkitt\.com/, BASE_URL);
    url = url.replace(/\/chapters\/.*$/, ""); // remove /chapters/N if present
    url = url.replace(/\/$/, "");

    var res = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        }
    });
    if (!res.ok) return Response.error("Cannot load: " + res.status);

    var doc = res.html();
    var chapters = [];
    var seen = {};

    // Inkitt chapter links: a[href*="/chapters/"] on the detail page
    // They typically look like: /stories/1698711/chapters/1
    doc.select("a[href*='/chapters/']").forEach(function(el) {
        var chapUrl = (el.attr("href") || "") + "";
        if (!chapUrl) return;
        if (!chapUrl.startsWith("http")) chapUrl = BASE_URL + chapUrl;

        if (seen[chapUrl]) return;
        seen[chapUrl] = true;

        // Chapter name: use the link text; fallback to chapter number from URL
        var name = el.text().trim() + "";
        if (!name) {
            var m = chapUrl.match(/\/chapters\/(\d+)/);
            name = m ? "Chapter " + m[1] : chapUrl;
        }

        chapters.push({
            name: name,
            url: chapUrl,
            host: BASE_URL
        });
    });

    if (chapters.length === 0) return Response.error("No chapters found");
    return Response.success(chapters);
}