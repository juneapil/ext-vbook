load('config.js');

function execute(url) {
    url = url.replace(/^https?:\/\/(www\.)?inkitt\.com/, BASE_URL);

    var res = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        }
    });

    if (!res.ok) {
        return Response.error("Cannot load chapter: " + res.status);
    }

    var doc = res.html();

    // remove rác
    doc.select("script, style, iframe, noscript").remove();
    doc.select("ins").remove();

    doc.select("[class*='ads']").remove();
    doc.select("[id*='ads']").remove();
    doc.select("[class*='banner']").remove();
    doc.select("[class*='advertisement']").remove();

    // remove inline comment counter
    doc.select(".inline-comments-count-container").remove();
    doc.select(".inline-comments-count").remove();

    // ===== chapter content =====
    var contentEl = null;

    var selectors = [
        "#chapterText",
        ".story-page-text",
        ".story-text",
        "[class*='story-text']",
        "[class*='chapter-content']",
        "article"
    ];

    for (var i = 0; i < selectors.length; i++) {
        var el = doc.select(selectors[i]).first();

        if (el && el.text().trim().length > 50) {
            contentEl = el;
            break;
        }
    }

    if (!contentEl) {
        return Response.error("No chapter content found");
    }

    // chỉ lấy nội dung p
    var html = "";

    contentEl.select("p").forEach(function (p) {
        var text = p.html().trim();

        if (text.length > 0) {
            html += "<p>" + text + "</p>";
        }
    });

    // cleanup
    html = html.replace(/&nbsp;/g, " ");
    html = html.replace(/\s{3,}/g, " ");

    return Response.success(html);
}