// detail.js — Thông tin chi tiết một truyện trên Inkitt
// Contract: execute(url) → { name*, cover, host, author, description, ongoing:bool*,
//                             genres?:[{title,input,script}], suggests?:[{title,input,script}] }
// Detail URL: https://www.inkitt.com/stories/1698711
load('config.js');
function execute(url) {
    // Normalize URL
    url = url.replace(/^https?:\/\/(www\.)?inkitt\.com/, BASE_URL);

    var res = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        }
    });
    if (!res.ok) return Response.error("Cannot load: " + res.status);

    var doc = res.html();

    // === Title ===
    // Try og:title meta tag first (most reliable), then h1
    var name = "";
    var ogTitleEl = doc.select("meta[property='og:title']").first();
    if (ogTitleEl) {
        name = (ogTitleEl.attr("content") || "") + "";
        // Inkitt og:title format: "StoreName by AuthorName at Inkitt" — strip the tail
        name = name.replace(/ by .+ at Inkitt$/i, "").trim();
    }
    if (!name) {
        var h1El = doc.select("h1").first();
        name = h1El ? (h1El.text().trim() + "") : "";
    }

    // === Cover ===
    var cover = "";
    var ogImageEl = doc.select("meta[property='og:image']").first();
    if (ogImageEl) {
        cover = (ogImageEl.attr("content") || "") + "";
    }
    if (!cover) {
        // Fallback: first cloudfront img on the page
        var coverImgEl = doc.select("img[src*='cloudfront'], img[src*='inkitt']").first();
        if (coverImgEl) {
            cover = (coverImgEl.attr("data-src") || coverImgEl.attr("src") || "") + "";
            if (cover.startsWith("//")) cover = "https:" + cover;
        }
    }

    // === Author ===
    // Author link: a[href*="/users/"] — the one that's visible as the byline
    var author = "";
    var authorLinks = doc.select("a[href*='/users/']");
    authorLinks.forEach(function(el) {
        var txt = el.text().trim() + "";
        if (txt && !author) author = txt;
    });

    // === Status (ongoing / completed) ===
    // Inkitt shows "Complete" badge or "Ongoing" — look for text patterns
    var ongoing = true;
    var statusEl = doc.select("[class*='status'], [class*='complete'], [class*='finished'], span:contains(Complete), span:contains(Ongoing), span:contains(Finished)").first();
    if (statusEl) {
        var statusText = statusEl.text().toLowerCase() + "";
        if (statusText.indexOf("complete") !== -1 || statusText.indexOf("finish") !== -1) {
            ongoing = false;
        }
    }

    // === Description ===
    // og:description has the plaintext blurb
    var description = "";
    var ogDescEl = doc.select("meta[property='og:description'], meta[name='description']").first();
    if (ogDescEl) {
        description = (ogDescEl.attr("content") || "") + "";
    }
    // Wrap in <p> for VBook rendering
    if (description) {
        description = "<p>" + description.replace(/\n+/g, "</p><p>") + "</p>";
    }
    // Fallback: find a long text paragraph near the story detail area
    if (!description) {
        doc.select("p, div[class*='synopsis'], div[class*='description'], div[class*='story-text']").forEach(function(el) {
            if (!description && el.text().trim().length > 80) {
                description = el.html() + "";
            }
        });
    }

    // === Genres ===
    var genres = [];
    doc.select("a[href*='/genres/']").forEach(function(el) {
        var gTitle = el.text().trim() + "";
        var gHref = (el.attr("href") || "") + "";
        if (!gTitle || !gHref) return;
        if (!gHref.startsWith("http")) gHref = BASE_URL + gHref;
        // Skip sub-genre duplicates – only keep direct genre URLs
        // e.g. /genres/action is fine; /genres/action/organized-crime also fine
        genres.push({ title: gTitle, input: gHref + "?page={{page}}", script: "gen.js" });
    });

    // === Suggests (search by author) ===
    var suggests = [];
    if (author) {
        suggests.push({ title: "More by " + author, input: author, script: "search.js" });
    }

    return Response.success({
        name: name,
        cover: cover,
        host: BASE_URL,
        author: author,
        description: description,
        ongoing: ongoing,
        format: "series",
        genres: genres.length > 0 ? genres : undefined,
        suggests: suggests.length > 0 ? suggests : undefined
    });
}