load('config.js');

// Hardcoded genre list from https://bachngoclau.com
function execute() {
    return Response.success([
        { title: "HE", input: BASE_URL + "/the-loai/he/", script: "gen.js" },
        { title: "Ngôn Tình", input: BASE_URL + "/the-loai/ngon-tinh/", script: "gen.js" },
        { title: "Hài Hước", input: BASE_URL + "/the-loai/hai-huoc/", script: "gen.js" },
        { title: "Tâm Lý", input: BASE_URL + "/the-loai/tam-ly/", script: "gen.js" },
        { title: "Nữ Cường", input: BASE_URL + "/the-loai/nu-cuong/", script: "gen.js" },
        { title: "Sủng", input: BASE_URL + "/the-loai/sung/", script: "gen.js" },
        { title: "Ngược Tâm", input: BASE_URL + "/the-loai/nguoc-tam/", script: "gen.js" },
        { title: "Gia Đình", input: BASE_URL + "/the-loai/gia-dinh/", script: "gen.js" },
        { title: "Hiện Đại", input: BASE_URL + "/the-loai/hien-dai/", script: "gen.js" },
        { title: "Cổ Trang", input: BASE_URL + "/the-loai/co-trang/", script: "gen.js" }
    ]);
}
