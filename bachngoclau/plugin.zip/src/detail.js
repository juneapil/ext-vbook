load('config.js');

function execute(url) {
    let response = fetch(url);
    if (!response.ok) return null;

    let doc = response.html();

    // Title
    let name = doc.select('.fs-3').text();

    // Cover image
    let cover = doc.select('.story-thumb img').attr('src');

    // Author – look for "Tác giả" label
    let author = doc.select('div.flex-fill:contains(Nhà dịch) a').text().trim();

    // Status
    let detail = doc.select('div.flex-fill:contains(Trạng thái) .mt-4')
        .text()
        .trim();

    // Description – grab the synopsis block
    let description = doc.select('.story-short-desc').text().trim();

    // Genres from nav/tags
    let genres = [];
    doc.select('a[href*="/the-loai/"]').forEach(function (a) {
        let title = a.text().trim();
        let input = a.attr('href');
        if (title && genres.filter(function (g) { return g.title === title; }).length === 0) {
            genres.push({ title: title, input: input, script: 'gen.js' });
        }
    });

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: description,
        detail: detail,
        genres: genres,
        host: BASE_URL
    });
}
