load('config.js');

function execute(url) {
    let response = fetch(url);
    if (!response.ok) return null;

    let doc = response.html();

    // Lấy nội dung chương
    let contentEl = doc.select('#chapContent, .chap-content').first();

    if (!contentEl) {
        return Response.success('');
    }

    // Xóa tag không cần
    contentEl.select(`
        script,
        style,
        iframe,
        .ads,
        .adsbygoogle,
        .quangcao,
        .modal
    `).remove();

    // Lấy html
    let html = contentEl.html();

    return Response.success(html.trim());
}