load('config.js');

function execute() {
    return Response.success([
        { title: "Truyện Mới", input: BASE_URL + "/truyen/", script: "gen.js" },
        { title: "Truyện Full", input: BASE_URL + "/truyen-full/", script: "gen.js" },
        { title: "Hiện Đại", input: BASE_URL + "/the-loai/hien-dai/", script: "gen.js" },
        { title: "Cổ Trang", input: BASE_URL + "/the-loai/co-trang/", script: "gen.js" }
    ]);
}
