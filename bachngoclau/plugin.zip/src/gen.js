load('config.js');

function execute(url, page) {
    if (!page) page = '1';

    let fetchUrl;

    if (page === '1') {
        fetchUrl = url;
    } else {
        fetchUrl = url.replace(/\/$/, '') + '/page/' + page + '/';
    }

    let response = fetch(fetchUrl);
    if (!response.ok) return null;

    let doc = response.html();

    let novelList = [];

    // Lấy danh sách truyện
    doc.select('.stories-list .story').forEach(function (e) {

        let linkEl = e.select('a.story-thumb').first();
        let imgEl = e.select('a.story-thumb img').first();

        let titleEl = e.select('a.fs-6').last();

        let name = titleEl ? titleEl.text().trim() : '';

        let link = linkEl ? linkEl.attr('href').trim() : '';

        let cover = '';

        if (imgEl) {
            cover = imgEl.attr('data-src') || imgEl.attr('src') || '';
        }

        if (name && link) {
            novelList.push({
                name: name,
                link: link,
                cover: cover,
                host: BASE_URL
            });
        }
    });

    // Next page
    let next = '';

    let nextEl = doc.select('.next, a.next, .page-numbers.next').first();

    if (nextEl) {
        let href = nextEl.attr('href');

        let match = href.match(/\/page\/(\d+)\//);

        if (match) {
            next = match[1];
        }
    }

    return Response.success(novelList, next);
}