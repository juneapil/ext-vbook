load('config.js');

function execute(url) {
    let response = fetch(url);
    if (!response.ok) return null;

    let doc = response.html();
    let chapters = [];

    // Chapter links follow the pattern: ?chuong-id=N
    // They appear in reverse order on site (newest first), so we reverse to get oldest first
    let chapterEls = doc.select('a[href*="chuong-id"]');

    // Use a map to deduplicate by href
    let seen = {};
    let rawList = [];
    for (let i = 0; i < chapterEls.size(); i++) {
        let a = chapterEls.get(i);
        let href = a.attr('href');
        let text = a.text().trim();

        // Skip navigation links like "Chương đầu" / "Chương cuối" / "Chương trước" / "Chương sau"
        if (!href || !text) continue;
        if (seen[href]) continue;
        seen[href] = true;

        rawList.push({ name: text, url: href });
    }

    // Sort by chuong-id ascending
    rawList.sort(function(a, b) {
        let ma = a.url.match(/chuong-id=(-?\d+)/);
        let mb = b.url.match(/chuong-id=(-?\d+)/);
        let na = ma ? parseInt(ma[1]) : 0;
        let nb = mb ? parseInt(mb[1]) : 0;
        return na - nb;
    });

    // Filter out invalid ids (negative means no chapter)
    rawList = rawList.filter(function(c) {
        let m = c.url.match(/chuong-id=(-?\d+)/);
        return m && parseInt(m[1]) >= 0;
    });

    rawList.forEach(function(c) {
        chapters.push({
            name: c.name,
            url: c.url,
            host: BASE_URL
        });
    });

    return Response.success(chapters);
}
