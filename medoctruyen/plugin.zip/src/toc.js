load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    url = normalizeUrl(url);

    // Tải và render JS động, chỉ bắt đầu khi có selector a chứa link chương
    var doc = loadDocument(url, 20000, "a[href*='/chuong-']");
    if (!doc) return Response.success([]);

    var chapters = [];
    var seen = {};

    // Sử dụng selector cực kỳ thực dụng để chỉ lấy các link chương trong lưới mục lục chính (.min-w-0 .grid)
    // Tự động loại bỏ nút "Đọc từ đầu" và "Chương mới nhất" ở ngoài lưới này
    var elements = doc.select(".min-w-0 .grid a[href*='/chuong-']");
    if (getSize(elements) === 0) elements = doc.select(".grid a[href*='/chuong-']");
    if (getSize(elements) === 0) elements = doc.select("a[href*='/chuong-']");

    for (var i = 0; i < getSize(elements); i++) {
        var el = getElement(elements, i);
        if (!el) continue;

        // Loại bỏ các thẻ con chứa chữ Miễn phí / Free
        el.select("span:contains(Miễn phí), span:contains(Free), span:contains(miễn phí), span:contains(free)").remove();

        var name = cleanText(el.text());
        var href = el.attr("href") || "";
        if (!name || !href) continue;

        // Làm sạch text chương
        name = name.replace(/\s*[\(\[-]?\s*(miễn phí|free|Miễn phí|Free)\s*[\)\]-]?/gi, "").trim();
        name = cleanText(name);
        if (!name || name === "Đọc từ đầu" || name === "Đọc tiếp" || name === "Đọc ngay") continue;

        var chapUrl = normalizeUrl(href);
        if (seen[chapUrl]) continue;
        seen[chapUrl] = true;

        chapters.push({
            name: name,
            url: chapUrl,
            host: BASE_URL
        });
    }

    return Response.success(chapters);
}
