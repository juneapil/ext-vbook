function execute(url) {

    try {

        var res = fetch(url);

        if (!res.ok) {
            return Response.error("Không thể tải chương");
        }

        var doc = res.html();

        var box = doc.select("div.book-list.full-story.content.chapter-c");

        if (box.size() === 0) {
            return Response.error("Không tìm thấy nội dung");
        }

        var html = "";

        // Lấy html thô
        var raw = box.html() + "";

        // ===== Có thẻ p =====
        if (raw.indexOf("<p") !== -1) {

            var reg = /<p[^>]*>([\s\S]*?)<\/p>/gi;

            while (true) {

                var m = reg.exec(raw);

                if (!m) {
                    break;
                }

                var fullTag = m[0] + "";
                var inner = m[1] + "";

                // Bỏ p quảng cáo
                if (fullTag.indexOf("mshow-db") !== -1) {
                    continue;
                }

                // text trong p
                var text = inner
                    .replace(/<[^>]+>/g, "")
                    .replace(/&nbsp;/g, " ")
                    .replace(/\s+/g, " ")
                    .trim();

                // Nếu p rỗng => lấy text trong attribute random
                if (text === "") {

                    var attrReg = /([a-zA-Z0-9_-]+)="([^"]*)"/g;

                    while (true) {

                        var a = attrReg.exec(fullTag);

                        if (!a) {
                            break;
                        }

                        var key = a[1] + "";
                        var val = a[2] + "";

                        // bỏ attribute hệ thống
                        if (
                            key === "class" ||
                            key === "style" ||
                            key === "onmousedown" ||
                            key === "onselectstart" ||
                            key === "oncopy" ||
                            key === "oncut"
                        ) {
                            continue;
                        }

                        val = val
                            .replace(/&nbsp;/g, " ")
                            .replace(/\s+/g, " ")
                            .trim();

                        if (val !== "") {
                            text = val;
                            break;
                        }
                    }
                }

                text = text
                    .replace(/&nbsp;/g, " ")
                    .replace(/\s+/g, " ")
                    .trim();
                var check = text.toLowerCase();
                // Xóa ads metruyenhot
                if (
                check.indexOf("metruyenhot") !== -1 ||
                check.indexOf("metruyenh0t") !== -1
            ) {
                continue;
            }

                if (text !== "") {
                    html += "<p>" + text + "</p>";
                }
            }

        } else {

            // ===== Không có p =====

            raw = raw
                .replace(/<br\s*\/?>/gi, "\n")
                .replace(/<\/div>/gi, "\n");

            var textOnly = Html.parse(raw).text() + "";

            var lines = textOnly.split("\n");

            for (var i = 0; i < lines.length; i++) {

                var line = (lines[i] + "")
                    .replace(/\s+/g, " ")
                    .trim();

                if (line !== "") {
                    html += "<p>" + line + "</p>";
                }
            }
        }
        

        return Response.success(html);

    } catch (e) {

        return Response.error(e + "");
    }
}