function execute(url) {

    try {

        var pages = [];

        var baseUrl = url.replace(/\/$/, "");

        // page 1
        pages.push(baseUrl);

        var res = fetch(baseUrl);

        if (!res.ok) {
            return Response.success(pages);
        }

        var doc = res.html();

        var last = 1;

        var plist = doc.select(".pagination a");

        for (var i = 0; i < plist.size(); i++) {

            var href = plist.get(i).attr("href") + "";

            var m = href.match(/page=(\d+)/);

            if (!m) {
                continue;
            }

            var num = parseInt(m[1], 10);

            if (num > last) {
                last = num;
            }
        }

        // page 2+
        for (var j = 2; j <= last; j++) {

            pages.push(
                baseUrl + "?page=" + j
            );
        }

        return Response.success(pages);

    } catch (e) {

        return Response.error(e + "");
    }
}