load("config.js");

function execute(url) {

    try {

        var res = fetch(url);

        if (!res.ok) {
            return Response.error("Không thể tải truyện");
        }

        var doc = res.html();

        // ===== name =====
        var name = doc.select("h1.title a").text() + "";

        // ===== cover =====
        var cover = doc.select(".col-12.col-md-4 img").attr("src") + "";

        if (!cover) {
            cover = doc.select(".col-12.col-md-4 img").attr("data-src") + "";
        }

        // ===== author =====
        var author = doc.select("span[itemprop=author]").text() + "";

        // ===== status =====
        var status = doc.select("span.status").text() + "";

        var ongoing = true;

        if (
            status.indexOf("Full") !== -1 ||
            status.indexOf("FULL") !== -1
        ) {
            ongoing = false;
        }

        // ===== description =====
        var content = doc.select("div.content1");

        // Xóa phần info
        content.select("div.info").remove();

        var desc = "";

        var plist = content.select("p");

        var start = false;

        for (var i = 0; i < plist.size(); i++) {

            var text = plist.get(i).text() + "";

            if (text.indexOf("Thông tin chi tiết") !== -1) {
                start = true;
                continue;
            }

            if (!start) {
                continue;
            }

            text = text
                .replace(/\s+/g, " ")
                .trim();

            if (text === "") {
                continue;
            }

            desc += "<p>" + text + "</p>";
        }

        // ===== genres =====
        var browser = Engine.newBrowser();

try {

    browser.setUserAgent(UserAgent.android());

    browser.launch(url, 15000);

    var doc = browser.html();

    var genres = [];

    var glist = doc.select("span[itemprop=genre]");

    for (var j = 0; j < glist.size(); j++) {

        var title = glist.get(j).text() + "";

        title = title
            .replace(/\s+/g, " ")
            .trim();

        if (!title) {
            continue;
        }

        var slug = title.toLowerCase();

        slug = slug
            .replace(/đ/g, "d")
            .replace(/[áàảãạăắằẳẵặâấầẩẫậ]/g, "a")
            .replace(/[éèẻẽẹêếềểễệ]/g, "e")
            .replace(/[íìỉĩị]/g, "i")
            .replace(/[óòỏõọôốồổỗộơớờởỡợ]/g, "o")
            .replace(/[úùủũụưứừửữự]/g, "u")
            .replace(/[ýỳỷỹỵ]/g, "y")
            .replace(/\s+/g, "-")
            .replace(/[^a-z0-9-]/g, "");

        genres.push({
            title: title,
            input: BASE_URL + "/the-loai/" + slug + "/",
            script: "gen.js"
        });
    }

} finally {

    browser.close();
}


        return Response.success({
            name: name,
            cover: cover,
            host: BASE_URL,
            author: author,
            description: desc,
            ongoing: ongoing,
            genres: genres
        });

    } catch (e) {

        return Response.error(e + "");
    }
}