load("config.js");

function execute(key, page) {

    try {

        page = page ? page : "1";

        // encode đúng cho web này
        key = encodeURIComponent(key)
            .replace(/%20/g, "+");

        var url =
            BASE_URL +
            "/tim-truyen?q=" +
            key;

        // page > 1
        if (page !== "1") {
            url += "&page=" + page;
        }

        var res = fetch(url);

        if (!res.ok) {
            return Response.error("Không thể tìm truyện");
        }

        var doc = res.html();

        var data = [];

        let list = doc.select(
            ".grid-items.show-list-home-select .row.row-custom > div"
        );

        for (var i = 0; i < list.size(); i++) {

            var item = list.get(i);

            var a = item.select("a").first();

            if (!a) {
                continue;
            }

            var name =
                item.select(".name-book").text() + "";

            if (!name) {
                continue;
            }

            var link =
                a.attr("href") + "";

            var cover =
                item.select("img.image-book")
                    .attr("src") + "";

            if (!cover) {

                cover =
                    item.select("img.image-book")
                        .attr("data-src") + "";
            }

            var description =
                item.select(".rate").text() + "";

            data.push({
                name: name,
                link: BASE_URL + link,
                cover: cover,
                description: description,
                host: BASE_URL
            });
        }

        // next page
        var next = null;

        var more = doc.select(
            "#list-more-search-page"
        );

        if (more.size() > 0) {

            var nextPage =
                more.attr("data-page") + "";

            if (
                nextPage &&
                nextPage !== "0"
            ) {
                next = nextPage;
            }
        }

        return Response.success(
            data,
            next
        );

    } catch (e) {

        return Response.error(
            e + ""
        );
    }
}