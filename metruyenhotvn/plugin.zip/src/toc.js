load("config.js");

function execute(url) {

    try {

        var res = fetch(url);

        if (!res.ok) {
            return Response.error("Không thể tải mục lục");
        }

        var doc = res.html();

        var data = [];

        var html = doc.html() + "";

var reg = /<div class="book-list story-details list-chap"[\s\S]*?<\/ul>\s*<\/div>\s*<\/div>/i;

var m = reg.exec(html);

if (!m) {
    return Response.error("Không tìm thấy danh sách chương");
}

var chapHtml = m[0] + "";

var box = Html.parse(chapHtml);

var list = box.select("li a");
        for (var i = 0; i < list.size(); i++) {

            var item = list.get(i);

            var name = item.text() + "";

            var chapUrl = item.attr("href") + "";

            data.push({
                name: name,
                url: chapUrl,
                host: BASE_URL
            });
        }

        // sort đúng thứ tự
        data.sort(function(a, b) {

            var na = a.name.match(/\d+/);
            var nb = b.name.match(/\d+/);

            var ca = na ? parseInt(na[0], 10) : 0;
            var cb = nb ? parseInt(nb[0], 10) : 0;

            return ca - cb;
        });

        return Response.success(data);

    } catch (e) {

        return Response.error(e + "");
    }
}