load("config.js");

function execute() {

    return Response.success([

        {
            title: "Truyện Mới",
            input: BASE_URL + "/danh-sach/truyen-moi-cap-nhat/",
            script: "gen.js"
        },
        {
            title: "Kiếm-Tiên Hiệp",
            input: BASE_URL + "/danh-sach/kiem-hiep-hay/",
            script: "gen.js"
        },
        {
            title: "Truyện Full",
            input: BASE_URL + "/danh-sach/truyen-full/",
            script: "gen.js"
        },
        {
            title: "Truyện Hot",
            input: BASE_URL + "/danh-sach/truyen-hot/",
            script: "gen.js"
        }
    ]);
}