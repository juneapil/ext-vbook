load("config.js");

function execute(input, page) {

    try {

        page = page ? page : "1";

        var url = input;

        // thêm page
        if (url.indexOf("?") !== -1) {
            url += "&page=" + page;
        } else {
            url += "?page=" + page;
        }

        var res = fetch(url);

        if (!res.ok) {
            return Response.error("Không thể tải thể loại");
        }

        var doc = res.html();

        var data = [];

        var list = doc.select("table.list-story-show tr");

        for (var i = 0; i < list.size(); i++) {

            var item = list.get(i);

            var a = item.select("h3.rv-home-a-title a");

            if (a.size() === 0) {
                continue;
            }

            // name
            var name = a.text() + "";

            // link
            var link = a.attr("href") + "";

            // cover
            var img = item.select("td.image img");

            var cover = img.attr("src") + "";

            if (!cover) {
                cover = img.attr("data-src") + "";
            }

            // description
            var description =
                item.select("td.chap.pc a").text() + "";

            data.push({
                name: name,
                link: link,
                host: BASE_URL,
                cover: cover,
                description: description
            });
        }

        // next page
        var next = null;

        var nextBtn = doc.select(".pagination .active + li a");

        if (nextBtn.size() > 0) {

            next = String(parseInt(page, 10) + 1);
        }

        return Response.success(data, next);

    } catch (e) {

        return Response.error(e + "");
    }
}