load('config.js');

function execute(url, page) {
    let response = fetch(BASE_URL + "/the-loai");
    if (response.ok) {
        let doc = response.html();
        const data = [];
        doc.select(".genres-grid .genre-item a").forEach(e => {
            data.push({
                title: e.select("a").text(),
                input: e.select("a").attr("href"),
                script: "source.js"
            })
        });
        return Response.success(data);
    }
    return null;
}