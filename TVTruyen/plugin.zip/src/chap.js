load('config.js');

function execute(url) {
    let response = fetch(url, {
        headers: {
            "referer": "https://www.tvtruyen.com/",
        }
    });

    if (response.ok) {
        let doc = response.html();
        let content = doc.select("#chapter-content");
        
        // Use .html() to check if content exists since JSoup Elements .length is undefined in Rhino
        if (content.html()) {
            content.select("h1").remove();
            content.select("h2").remove();
            content.select("h3").remove();
            return Response.success(content.html());
        }
    }
    return Response.error("Không thể tải nội dung chương. Vui lòng thử lại sau.");
}