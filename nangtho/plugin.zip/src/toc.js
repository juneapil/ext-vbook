
function execute(url) {
    let doc = Http.get(url).html();

    let list = [];

    doc.select(".story-detail__list-chapter--list a")
        .forEach(e => {
            list.push({
                name: e.text().trim(),
                url: e.attr("href")
            });
        });

    return Response.success(list);
}