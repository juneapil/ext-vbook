load("config.js");

function execute(url) {
    let doc = Http.get(url).html();

    let name = doc.select(".story-name").text().trim();

    let cover = doc.select(".book-3d img").attr("src");

    let author = doc.select(
        "p:contains(Tác giả) a"
    ).text().trim();

    let description = doc.select(
        ".story-detail__top--desc"
    ).text().trim();

    let ongoing = doc.select(
        "p:contains(Trạng thái) span"
    ).text().trim();

    return Response.success({
        name: name,
        cover: cover,
        host: BASE_URL,
        author: author,
        description: description,
        ongoing: ongoing
    });
}