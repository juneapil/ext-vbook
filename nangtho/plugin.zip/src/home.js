load("config.js");

function execute() {
    return Response.success([
        {
            title: "Truyện Hot",
            input: BASE_URL,
            script: "gen.js"
        }
    ]);
}