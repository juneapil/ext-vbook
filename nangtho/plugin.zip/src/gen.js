load("config.js");

function execute(url) {
    let doc = Http.get(url).html();

    let list = [];

    doc.select(".section-stories-hot .story-item")
        .forEach(e => {

            let a = e.select("a").first();

            let name = e.select(".story-name")
                .text()
                .trim();

            let link = a.attr("href");

            let cover = e.select("img")
                .attr("src");

            list.push({
                name: name,
                link: link,
                host: BASE_URL,
                cover: cover
            });
        });

    return Response.success(list);
}
