
function execute() {

    let doc = Http.get(BASE_URL).html();

    let genres = [];
    let added = {};

    doc.select(".dropdown-menu-custom .dropdown-item")
        .forEach(e => {

            let title = e.text().trim();

            let link = e.attr("href");

            // chỉ lấy link thể loại
            if (
                link.indexOf("/the-loai/") > -1 &&
                !added[link]
            ) {

                added[link] = true;

                genres.push({
                    title: title,
                    input: link,
                    script: "gen.js"
                });
            }
        });

    return Response.success(genres);
}