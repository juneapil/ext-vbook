function execute(url) {
    let doc = Http.get(url).html();

    let content = doc.select("div.chapter-content");

    content.select("style").remove();
    content.select("script").remove();

    return Response.success(content.html());
}