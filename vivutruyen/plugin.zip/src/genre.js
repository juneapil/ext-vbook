function execute() {
    const genres = [
        { title: "Ngược", url: "https://vivutruyen.net/nguoc/" },
        { title: "Ngôn Tình", url: "https://vivutruyen.net/ngon-tinh/" },
        { title: "Truyện Teen", url: "https://vivutruyen.net/truyen-teen/" },
        { title: "Shoujo", url: "https://vivutruyen.net/shoujo/" },
        { title: "Truyện Chữ", url: "https://vivutruyen.net/truyen-chu/" },
        { title: "Trọng Sinh", url: "https://vivutruyen.net/trong-sinh/" },
        { title: "Truyện Tranh", url: "https://vivutruyen.net/truyen-tranh/" },
        { title: "Sủng", url: "https://vivutruyen.net/sung/" },
        { title: "Sắc", url: "https://vivutruyen.net/sac/" },
        { title: "Smut", url: "https://vivutruyen.net/smut/" },
        { title: "Tiểu Thuyết", url: "https://vivutruyen.net/tieu-thuyet/" },
        { title: "Khoa Huyễn", url: "https://vivutruyen.net/khoa-huyen/" },
        { title: "Nữ Phụ", url: "https://vivutruyen.net/nu-phu/" },
        { title: "School Life", url: "https://vivutruyen.net/school-life/" },
        { title: "Slice of life", url: "https://vivutruyen.net/slice-of-life/" },
        { title: "Mạt Thế", url: "https://vivutruyen.net/mat-the/" },
        { title: "Night Owl", url: "https://vivutruyen.net/night-owl/" },
        { title: "Trinh Thám", url: "https://vivutruyen.net/trinh-tham/" },
        { title: "Huyền Huyễn", url: "https://vivutruyen.net/huyen-huyen/" },
        { title: "Cổ Đại", url: "https://vivutruyen.net/co-dai/" },
        { title: "Hài Hước", url: "https://vivutruyen.net/hai-huoc/" },
        { title: "Hiện đại", url: "https://vivutruyen.net/hien-dai/" },
        { title: "Đô Thị", url: "https://vivutruyen.net/do-thi/" },
        { title: "Khác", url: "https://vivutruyen.net/khac/" },
        { title: "Xuyên Không", url: "https://vivutruyen.net/xuyen-khong/" },
        { title: "Cung Đấu", url: "https://vivutruyen.net/cung-dau/" },
        { title: "Gia Đấu", url: "https://vivutruyen.net/gia-dau/" },
        { title: "Adult", url: "https://vivutruyen.net/adult/" },
        { title: "Harem", url: "https://vivutruyen.net/harem/" },
        { title: "Manhwa", url: "https://vivutruyen.net/manhwa/" },
        { title: "Điền Văn", url: "https://vivutruyen.net/dien-van/" },
        { title: "Đoản Văn", url: "https://vivutruyen.net/doan-van/" },
        { title: "Nữ Cường", url: "https://vivutruyen.net/nu-cuong/" },
        { title: "Action", url: "https://vivutruyen.net/action/" },
        { title: "Hệ Thống", url: "https://vivutruyen.net/he-thong/" },
        { title: "Adventure", url: "https://vivutruyen.net/adventure/" },
        { title: "Drama", url: "https://vivutruyen.net/drama/" },
        { title: "Dị Giới", url: "https://vivutruyen.net/di-gioi/" },
        { title: "Xuyên sách", url: "https://vivutruyen.net/xuyen-sach/" },
        { title: "Tiên giới", url: "https://vivutruyen.net/tien-gioi/" },
        { title: "Linh dị", url: "https://vivutruyen.net/linh-di/" },
        { title: "Tâm linh", url: "https://vivutruyen.net/tam-linh/" },
        { title: "Kinh dị", url: "https://vivutruyen.net/kinh-di/" },
        { title: "Ngôn Linh", url: "https://vivutruyen.net/ngon-linh/" },
        { title: "Tâm lý", url: "https://vivutruyen.net/tam-ly/" },
        { title: "Kỳ ảo", url: "https://vivutruyen.net/ky-ao/" },
        { title: "Tiên hiệp", url: "https://vivutruyen.net/tien-hiep/" },
        { title: "Báo thù", url: "https://vivutruyen.net/bao-thu/" },
        { title: "Khoa học viễn tưởng", url: "https://vivutruyen.net/khoa-hoc-vien-tuong/" },
        { title: "Huyền ảo", url: "https://vivutruyen.net/huyen-ao/" },
        { title: "Giả tưởng khoa học", url: "https://vivutruyen.net/gia-tuong-khoa-hoc/" },
        { title: "BoyLove", url: "https://vivutruyen.net/boylove/" },
        { title: "Đam mỹ", url: "https://vivutruyen.net/dam-my/" },
        { title: "Tu Tiên", url: "https://vivutruyen.net/tu-tien/" }
    ];

    const data = [];
    for (let i = 0; i < genres.length; i++) {
        data.push({
            title: genres[i].title,
            input: genres[i].url,
            script: "gen.js"
        });
    }
    return Response.success(data);
}
