function execute() {
    const doc = Http.get("https://vivutruyen.net/").html();
    const el = doc.select(".danh-muc .cat-item a");
    const data = [];
    for (let i = 0; i < el.size(); i++) {
        const e = el.get(i);
        data.push({
            title: e.text(),
            input: 'https://vivutruyen.net' + e.attr("href"),
            script: "gen.js"
        });
    }
    return Response.success(data);
}
