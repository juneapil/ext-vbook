function execute(url, page) {
    if (!page) page = '1';
    let doc;
    if (page === '1') {
        doc = Http.get(url).html();
    } else {
        if (url.endsWith('/')) {
            doc = Http.get(url + "page/" + page + "/").html();
        } else {
            doc = Http.get(url + "/page/" + page + "/").html();
        }
    }

    const el = doc.select(".uk-cover-container");
    const data = [];
    for (let i = 0; i < el.size(); i++) {
        const e = el.get(i);
        let title = e.select("h3.de-cu-title").text();
        let chap = e.select(".chap-text").text() || e.select(".chap-title").text();
        if (chap) {
            title = title.replace(chap, "").trim();
        }

        let cover = e.select("img").attr("data-src") || e.select("img").attr("src");
        let link = e.select("a.uk-position-cover").attr("href");
        let host = "https://vivutruyen.net";

        data.push({
            name: title,
            link: link,
            cover: cover,
            description: chap,
            host: host
        });
    }

    // Trang dùng .uk-pagination với href, không có data-page
    let next = "";
    const nextEl = doc.select(".uk-pagination li.uk-active + li a");
    if (nextEl.size() > 0) {
        const nextHref = nextEl.attr("href") + "";
        const pageStr = "/page/";
        const idx = nextHref.indexOf(pageStr);
        if (idx >= 0) {
            const rest = nextHref.substring(idx + pageStr.length);
            const endIdx = rest.indexOf("/");
            next = endIdx >= 0 ? rest.substring(0, endIdx) : rest;
        }
    }

    return Response.success(data, next);
}
