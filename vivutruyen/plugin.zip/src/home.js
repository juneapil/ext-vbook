function execute() {
    return Response.success([
        { title: "Mới Cập Nhật", input: "https://vivutruyen.net/moi-cap-nhat/", script: "gen.js" },
        { title: "Mới Nhất", input: "https://vivutruyen.net/moi-nhat/", script: "gen.js" },
        { title: "Xem Nhiều", input: "https://vivutruyen.net/xem-nhieu/", script: "gen.js" },
        { title: "Đề Cử", input: "https://vivutruyen.net/de-cu/", script: "gen.js" }
    ]);
}
