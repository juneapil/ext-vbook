function execute() {
    return Response.success([
        { title: "Mới Cập Nhật", input: "https://vivutruyen.net/moi-cap-nhat/", script: "gen1.js" },
        { title: "Mới Nhất", input: "https://vivutruyen.net/moi-nhat/", script: "gen1.js" },
        { title: "Xem Nhiều", input: "https://vivutruyen.net/xem-nhieu/", script: "gen1.js" },
        { title: "Đề Cử", input: "https://vivutruyen.net/de-cu/", script: "gen1.js" }
    ]);
}
