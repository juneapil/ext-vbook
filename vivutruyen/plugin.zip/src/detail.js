function execute(url) {
    const doc = Http.get(url).html();

    let detail = "";
    const infoElements = doc.select(".info-truyen li");
    if (infoElements.size() > 1) {
        detail += infoElements.get(1).text() + "<br>";
    }
    if (infoElements.size() > 2) {
        detail += infoElements.get(2).text();
    }

    return Response.success({
        name: doc.select("h1 .title-truyen").text() || doc.select("h1").text(),
        cover: doc.select(".image-truyen img").attr("data-src") || doc.select(".image-truyen img").attr("src"),
        author: doc.select(".info-truyen li").first().text().replace("Tác giả:", "").trim() || "Unknown",
        description: doc.select(".noi-dung").html(),
        detail: detail,
        host: "https://vivutruyen.net"
    });
}
