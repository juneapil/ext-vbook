function execute(url) {
    const doc = Http.get(url).html();
    let content = doc.select(".reading").html();
    return Response.success(content);
}
