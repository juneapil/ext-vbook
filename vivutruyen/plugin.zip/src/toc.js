function execute(url) {
    let data = [];
    let added = {};

    let url1 = url.replace("vivutruyen.net", "vivutruyen2.net");
    let doc1 = Http.get(url1).html();
    if (doc1) {
        let el1 = doc1.select(".list .chap-title");
        for (let i = el1.size() - 1; i >= 0; i--) {
            let e = el1.get(i);
            let name = e.text();
            if (!added[name]) {
                data.push({
                    name: name,
                    url: e.attr("href"),
                    host: "https://vivutruyen2.net"
                });
                added[name] = true;
            }
        }
    }

    let url2 = url.replace("vivutruyen2.net", "vivutruyen.net");
    let doc2 = Http.get(url2).html();
    if (doc2) {
        let el2 = doc2.select(".list .chap-title");
        for (let i = el2.size() - 1; i >= 0; i--) {
            let e = el2.get(i);
            let name = e.text();
            if (!added[name]) {
                data.push({
                    name: name,
                    url: e.attr("href"),
                    host: "https://vivutruyen.net"
                });
                added[name] = true;
            }
        }
    }

    return Response.success(data);
}
