function execute(key, page) {
    if (!page) page = '1';
    
    let data = [];
    let added = {};
    let next = "";
    
    let urls = ["https://vivutruyen2.net", "https://vivutruyen.net"];
    
    for (let u = 0; u < urls.length; u++) {
        let domain = urls[u];
        let url = domain + "/";
        if (page !== '1') url = domain + "/page/" + page + "/";
        
        try {
            let doc = Http.get(url).params({s: key}).html();
            if (doc) {
                let el = doc.select(".uk-cover-container");
                for (let i = 0; i < el.size(); i++) {
                    try {
                        let e = el.get(i);
                        let title = e.select("h3.de-cu-title").text() + "";
                        let chap = e.select(".chap-text").text() + "";
                        if (!chap) chap = e.select(".chap-title").text() + "";
                        
                        if (chap) {
                            title = title.replace(chap, "").trim();
                        }
                        
                        let cover = e.select("img").attr("data-src") || e.select("img").attr("src");
                        let link = e.select("a.uk-position-cover").attr("href");
                        
                        if (!added[title]) {
                            data.push({
                                name: title,
                                link: link + "",
                                cover: cover + "",
                                description: chap,
                                host: domain
                            });
                            added[title] = true;
                        }
                    } catch (itemErr) {
                        // ignore item error
                    }
                }
                if (!next) {
                    let nextStr = doc.select(".pagination li.active + li a").attr("data-page");
                    if (nextStr) next = nextStr + "";
                }
            }
        } catch (err) {
            // ignore domain error
        }
    }

    return Response.success(data, next);
}
